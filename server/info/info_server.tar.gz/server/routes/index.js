var express = require('express');
var Common = require('../private/common');
var DBHelper=require('../db/DBHelper').Instance;
var crypto = require('crypto');

var router = express.Router();
function MD5(str){
  return crypto.createHash("md5").update(str).digest('hex');
}
var RoomIDCreater = new Common.RandomInt(100000,999999);
function Room(){
  this.roomid=0;
  this.openid="";
  this.timestamp = Date.now();
  this.hashcode="";
  this.playcount=0;
};
Room.prototype.CaculateHash=function(){
  this.hashcode = MD5(this.roomid.toString() + this.openid + this.timestamp.toString());
}
var GlobalRoom={};
function CreateRoom(openid){
  try {
    
    var id= RoomIDCreater.Get();
    var room = new Room();
    room.openid=openid;
    room.roomid = id;
    room.CaculateHash();
    GlobalRoom[room.roomid.toString()]=room;
    return room;
  } catch (error) {
    console.error("create room:"+error.message);
    return null;
  }
    
}
function GetRoom(roomid){
  return GlobalRoom[roomid];
}
function ReleaseRoom(roomid){
  var room = GlobalRoom[roomid];
  if(room){
    RoomIDCreater.ReleaseValue(parseInt(roomid));
    delete GlobalRoom[roomid];
    
  }
}
var ERROR_NONE=0;
var ERROR_USER_NOT_FOUND = 10001;
var ERROR_ROOM_IS_FULL = 10002;
var ERROR_ROOM_NOT_FOUND = 10003;
//跨域
router.all('*', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  res.header("Access-Control-Allow-Methods","PUT,POST,GET,DELETE,OPTIONS");
  res.header("X-Powered-By",' 3.2.1')
  res.header("Content-Type", "application/json;charset=utf-8");
  next();
});
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});
router.get('/getUserInfo',function(req,res,next){
  console.log(req.query);
  console.log(req.body);
    var openid = req.query.openid;
    if(openid == undefined || openid == null || openid==""){
      res.send({
        error:ERROR_USER_NOT_FOUND
      })
      return;
    }
    DBHelper.GetUserInfo(openid,true).then((data,error)=>{
      var data = data[0];
      data._id="";
      res.send(data);
    });
});
router.get('/createRoom',function(req,res,next){
  var openid = req.query.openid;
  DBHelper.GetUserInfo(openid).then((data,error)=>{
    if(data.length == 0){
      res.send({
        error:ERROR_USER_NOT_FOUND
      });
    }
    else{
      var room = CreateRoom(openid);
      if(room){
        res.send({
          roomid:room.roomid
        });
      }
      else{
        res.send({
          error:ERROR_ROOM_IS_FULL
        });
      }
      
    }
  });
});
//request in channel only
router.get('/checkRoom',function(req,res,next){
  var data = decodeURIComponent(req.query.data);
  console.log("checkroom:"+data);
  var json=JSON.parse(data);
  var roomid = json.roomid;
  var room = GetRoom(roomid);
  if(room){
    res.send(room);
  }else
  {
    res.send({error:ERROR_ROOM_NOT_FOUND});
  }
});
//request in channel only
router.get('/releaseRoom',function(req,res,next){
  var roomid = req.query.roomid;
  var hashcode = req.query.hashcode;
  var room = GetRoom(roomid);
  if(room && room.hashcode == hashcode){
    ReleaseRoom(roomid);
    res.send({error:ERROR_NONE});
  }
  else{
    res.send({error:ERROR_ROOM_NOT_FOUND});
  }
});
//request in channel only
router.get('/playEnd',function(req,res,next){
  console.log("playEnd:"+req.query.data);
  var data=JSON.parse(req.query.data);
  var roomid = data.roomid;
  var hashcode = data.hashcode;
  var room = GetRoom(roomid);
  if(room && room.hashcode == hashcode){
    room.playcount++;
    res.send(room);
  }
  else{
    res.send({error:ERROR_ROOM_NOT_FOUND});
  }
});
module.exports = router;
