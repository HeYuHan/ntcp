Import of CQ protobuf config from infra_internal repo.
Version: 614723941add42edbe1c8d5a04658967f15d2645 from Aug 18, 2017.
